## 2.1.0 (2026-07-08)

### Features

- Add stretch sample-rate constructor support and align Storybook playback-rate controls ([#83](https://github.com/cutterbl/SoundTouchJS/pull/83))

### ❤️ Thank You

- Steve 'Cutter' Blades

## 2.0.4 (2026-06-09)

### Bug Fixes

- Dependency updates ([#81](https://github.com/cutterbl/SoundTouchJS/pull/81))

### ❤️ Thank You

- Steve 'Cutter' Blades

## 2.0.3 (2026-05-15)

### Bug Fixes

- **release:** Use flat projectsRelationship, remove per-package GitHub releases ([#77](https://github.com/cutterbl/SoundTouchJS/pull/77))

### ❤️ Thank You

- Steve 'Cutter' Blades

## 2.0.2 (2026-05-15)

### Bug Fixes

- **release:** Set releaseTagPattern to match existing v{version} git tags ([#76](https://github.com/cutterbl/SoundTouchJS/pull/76))
- Release conventional commits ([#75](https://github.com/cutterbl/SoundTouchJS/pull/75))
- **release:** Remove duplicate conventionalCommits from version config ([#74](https://github.com/cutterbl/SoundTouchJS/pull/74))
- Release ([#73](https://github.com/cutterbl/SoundTouchJS/pull/73))
- Release ([#72](https://github.com/cutterbl/SoundTouchJS/pull/72))
- **ci:** Allow workflow_dispatch to bypass release commit check ([#70](https://github.com/cutterbl/SoundTouchJS/pull/70))
- **ci:** Remove paths-ignore from storybook pages trigger, add workflow_dispatch ([#69](https://github.com/cutterbl/SoundTouchJS/pull/69))

### ❤️ Thank You

- Steve 'Cutter' Blades